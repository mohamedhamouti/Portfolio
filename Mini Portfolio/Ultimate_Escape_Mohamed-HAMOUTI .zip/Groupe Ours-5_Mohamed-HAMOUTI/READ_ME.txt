Notre groupe a réalisé le projet n°5, celui de l'Ultimate Escape. Nous étions quatres Mohamed HAMOUTI (chef de projet),Noam BOUGHATF,
 Asouab Zinedine, Zackary SAADA. 

Concernant notre projet, celui-ci comporte 6 pages HTML et une page CSS, la plupart des consignes ont été réspécté sauf une concernant les images. 
Nous avons décidé de ne pas ajouter les images des groupes sur le sites directement mais nous avons choisis de les intergrer aux differents réseaux sociaux de l'Escape qui sont disponibles en Footer. 
Ces réseaux sociaux n'ont pas été crées mais c'est ce que nous imaginions. 
De plus, sur la page résérvation, une image cliquable est disponible, celle-ci renvoie à une autre page HTML sur laquelle on allait partir pour résérvé mais finalement cela a été abadonné pour l'intégrer
directement sur notre page résérvation. 